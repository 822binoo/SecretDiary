package com.example.secretdiary

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DiaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diary)
    }
}